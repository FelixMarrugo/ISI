<?php
    include("layout.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="./css/bootstrap.min.css">
</head>
<body>
    <div class="row justify-content-md-center">
        <div class="col-6">
            <h4 class="display-4">Mostrar Estadisticas</h4>
            <form method="POST">
                <div class="form-floating mb-3">
                    <input style= "margin-top:20px"type="text" class="form-control" id="floatingInput" name="identificacion">
                    <label for="floatingInput">Identificacion</label>
                </div>
                <div class="col">
                    <button type="submit" class="btn btn-primary mb-3" name="estadisticas">Consultar</button>
                </div>
            </form>
        </div>
    </div>
<?php
    include("Estadisticas.php"); 
?>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="./js/bootstrap.min.js"></script>
</body>
</html>