<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calcular IMC</title>

</head>
<body>
<?php
    include("layout.php");
?>

<div class="container">
    <div class="row justify-content-md-center">
        <div class="col-6">
            <form method = "POST">
                <h1 class="display-5">Calcular IMC</h1>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="floatingInput" placeholder="Identificacion" name= "identificacion">
                    <label for="floatingInput">Identificacion</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="floatingInput" placeholder="Altura" name= "m">
                    <label for="floatingInput">Estatura</label>
                </div>
                <div class="form-floating">
                    <input type="text" class="form-control" id="floatingInput" placeholder="Peso" name = "kg">
                    <label for="floatingInput">Peso</label>
                </div>
                <div class= "col-12" style = "margin-top:20px;">
                    <button type="submit" class="btn btn-primary btn-lg" style="m" name= "cIMC">Calcular</button>
                </div>
                
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">Identificacion</th>
                            <th scope="col">Peso</th>
                            <th scope="col">Estatura</th>
                            <th scope="col">Resultado [IMC]</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            if(isset($_REQUEST['cIMC'])){
                                $identificacion = $_REQUEST['identificacion'];
                                $peso = $_REQUEST['kg'];
                                $estatura = $_REQUEST['m'];
                                $imc = $peso / ($estatura * $estatura); 
                        ?>
                        <tr>
                            <th scope="row"><?php echo $identificacion;?></th>
                                <td><?php echo $peso;?></td>
                                <td><?php echo $estatura;?></td>
                                <td><?php echo $imc;?></td>
                        </tr>
                    <?php } ?>
                    </tbody>
                </table>
            </form>
        </div>
    </div>
</div>

<?php
    include("registrarIMC.php");
?> 

</body>
</html>