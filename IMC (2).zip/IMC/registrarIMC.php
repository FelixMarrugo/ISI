<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="./css/bootstrap.min.css">
</head>
<body>
    <?php
        include("con_db.php");

        if(isset($_POST["cIMC"])){
            if(strlen($_POST['identificacion']) >= 1 && strlen($_POST['m']) >=1 && strlen($_POST['kg']) >=1 ){
                $identificacion = trim($_POST['identificacion']);
                $m = trim($_POST['m']);
                $kg = trim($_POST['kg']);
                $fechareg = date("d/m/y");
                $imc = ($kg) / ($m * $m);
                $consulta1="INSERT INTO calcularimc(identificacion, peso, estatura, resultado, fecha_reg) VALUES ('$identificacion','$kg','$m','$imc','$fechareg')";
                $result = mysqli_query($conexion, $consulta1);
                if($result){
                    ?> 
                        <h4 class= "display-4">Registro exitoso</h4>
                    <?php
                } else{
                    ?> 
                        <h4>¡Ups ha ocurrido un error</h4>
                    <?php
                }
            } else {
                ?> 
                    <h4>Complete todos los campos..!</h4>
                <?php
            }
        }
    ?>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="./js/bootstrap.min.js"></script>
</body>
</html>