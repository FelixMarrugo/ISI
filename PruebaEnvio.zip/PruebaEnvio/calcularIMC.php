<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calcular IMC</title>

</head>
<body>
<?php
    include("layout.php");
?>

<div class="container">
    <div class="row justify-content-md-center">
        <div class="col-6">
            <form method = "POST">
                <h1 class="display-5">Calcular IMC</h1>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="floatingInput" placeholder="Altura" name= "m">
                    <label for="floatingInput">Altura</label>
                </div>
                <div class="form-floating">
                    <input type="text" class="form-control" id="floatingInput" placeholder="Peso" name = "kg">
                    <label for="floatingInput">Peso</label>
                </div>
                <div class= "col-12" style = "margin-top:20px;">
                    <button type="submit" class="btn btn-primary btn-lg" style="m" name= "cIMC">Calcular</button>
                </div>
                

                <?php

                  if(isset($_REQUEST['cIMC'])){
                    $peso = $_REQUEST['kg']; 
                    $altura  = $_REQUEST['m']; 

                    $imc = $peso / ($altura * $altura); 
                    echo "<br>"; 
                    echo "<h1>Peso [". $peso . "] </h1><br>";
                    echo "Altura [" .$altura . "]<br>";
                    echo "IMC [" . $imc . "]<br>"; 
                  }  

                ?>
            </form>
        </div>
    </div>
</div>
</body>
</html>