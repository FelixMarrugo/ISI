<?php
    $conexion = mysqli_connect("localhost", "root", "", "imc"); 

    if($conexion){
        echo "Todo correcto"; 
    } else {
        echo "No se pudo conectar a la DB"; 
    }

?>
