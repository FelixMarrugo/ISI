<?php
    include("layout.php");
    include("con_db.php");
    $estadisticas = "SELECT * from calcularimc"; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maqueta</title>

    <link rel="stylesheet" href="./css/bootstrap.min.css">
</head>
<body>
<div class="row justify-content-md-center">
        <div class="col-4">
            <form method="POST">
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="floatingInput" name="identificacion">
                    <label for="floatingInput">Identificacion</label>
                </div>
                <div class="col">
                    <button type="submit" class="btn btn-primary mb-3" name="estadisticas">Consultar</button>
                </div>
            </form>
        </div>
</div>

<div class="row justify-content-md-center">
    <div class="col-8">
        <table class="table table-success table-striped">
            <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Identificacion</th>
                    <th scope="col">Peso</th>
                    <th scope="col">Estatura</th>
                    <th scope="col">IMC</th>
                    <th scope="col">Fecha de registro</th>
                </tr>
            </thead>
            <tbody>

                <?php
                    $resultado = mysqli_query($conexion, $estadisticas);
                    while($row = mysqli_fetch_assoc($resultado)){
                ?>

                <tr>
                <th scope="row"><?php echo $row["id"];?></th>
                    <td><?php echo $row["identificacion"];?></td>
                    <td><?php echo $row["peso"];?></td>
                    <td><?php echo $row["estatura"];?></td>
                    <td><?php echo $row["resultado"];?></td>
                    <td><?php echo $row["fecha_reg"];?></td>
                </tr>
                <?php } //Cerramos la llave del while ?> 
            </tbody>
</table>
    </div>
</div>


<?php
    include("Estadisticas.php"); 
?>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="./js/bootstrap.min.js"></script>
</body>
</html>